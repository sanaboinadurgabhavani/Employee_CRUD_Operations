package org.employee.employee_CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
